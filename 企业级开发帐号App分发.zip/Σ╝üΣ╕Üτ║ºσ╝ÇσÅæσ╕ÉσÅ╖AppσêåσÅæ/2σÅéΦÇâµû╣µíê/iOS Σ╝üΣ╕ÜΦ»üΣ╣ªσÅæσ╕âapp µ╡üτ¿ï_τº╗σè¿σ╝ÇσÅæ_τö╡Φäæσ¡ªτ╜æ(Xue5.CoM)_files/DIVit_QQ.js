﻿

document.writeln("<script type=\"text\/javascript\">\/*xue5右下角悬浮250*200，5.16改为对联测试*\/ var cpro_id = \'u167980\';<\/script><script src=\"http:\/\/cpro.baidu.com\/cpro\/ui\/f.js\" type=\"text\/javascript\"><\/script>")




document.writeln("<script type=\"text\/javascript\">");
document.writeln("    (function(win,doc){");
document.writeln("        var s = doc.createElement(\"script\"), h = doc.getElementsByTagName(\"head\")[0];");
document.writeln("        if (!win.alimamatk_show) {");
document.writeln("            s.charset = \"gbk\";");
document.writeln("            s.async = true;");
document.writeln("            s.src = \"http:\/\/a.alimama.cn\/tkapi.js\";");
document.writeln("            h.insertBefore(s, h.firstChild);");
document.writeln("        };");
document.writeln("        var o = {");
document.writeln("            pid: \"mm_10165657_234131_13380554\",\/*推广单元ID，用于区分不同的推广渠道*\/");
document.writeln("            appkey: \"\",\/*通过TOP平台申请的appkey，设置后引导成交会关联appkey*\/");
document.writeln("            unid: \"\"\/*自定义统计字段*\/");
document.writeln("        };");
document.writeln("        win.alimamatk_onload = win.alimamatk_onload || [];");
document.writeln("        win.alimamatk_onload.push(o);");
document.writeln("    })(window,document);");
document.writeln("<\/script>");
document.writeln("")


document.writeln("<FONT style=\"FONT-SIZE: 8pt\" face=\"Verdana\">本网内容来自互联网转载分享,如侵犯您的版权,我们深感抱歉,请第一时间联系QQ:1103290，我们立刻删除<\/font><br><A href=\"http:\/\/www.itlaw.com.cn\/\" title=\"法律顾问\" target=\"_blank\">本站法律顾问: ITlaw-庄毅雄<\/A> ")







var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Fcadee88ca0c7c9650dc4380fd51a742a' type='text/javascript'%3E%3C/script%3E"));













