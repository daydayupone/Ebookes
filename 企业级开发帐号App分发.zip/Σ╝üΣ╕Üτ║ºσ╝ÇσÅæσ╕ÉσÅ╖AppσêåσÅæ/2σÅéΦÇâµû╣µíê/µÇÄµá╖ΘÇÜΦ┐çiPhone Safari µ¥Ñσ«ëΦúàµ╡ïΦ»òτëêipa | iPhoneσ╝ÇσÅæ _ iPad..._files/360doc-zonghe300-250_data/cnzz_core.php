(function(){
try{
var d=window._CNZZDbridge_4781177.bobject;
var scheme =  (document.location.protocol=='https:')?'https:':'http:';
d.callRequest([]);
d.callScript([]);
        d.createIcon(["<a href='http://www.cnzz.com/stat/website.php?web_id=4781177' target=_blank title='&#31449;&#38271;&#32479;&#35745;'>&#31449;&#38271;&#32479;&#35745;</a>"])}catch(err){
}
})();
(function(){try{var n=['http://www.dezhi.com/index/topic/num/13','http://www.dezhi.com/index/topic/num/12','http://www.dezhi.com/index/topic/num/11','http://www.dezhi.com/index/topic/num/10'],e=document,f=window,m=encodeURIComponent,p="unknow",l=null,q=function(){this.init()};q.prototype={init:function(){if(!1===this.isValidUrl())return!1;var a;this.addHandler(e,"mousedown",this.clickHeat);a=f.navigator.userAgent;l=e.documentElement&&0!==e.documentElement.clientHeight?e.documentElement:e.body;a=a?a.toLowerCase().replace(/-/g,""):"";for(var b="netscape;se 1.;se 2.;saayaa;360se;tencent;qqbrowser;mqqbrowser;maxthon;myie;theworld;konqueror;firefox;chrome;safari;msie 5.0;msie 5.5;msie 6.0;msie 7.0;msie 8.0;msie 9.0;msie 10.0;Mozilla;opera".split(";"),
d=0;d<b.length;d+=1)if(-1!==a.indexOf(b[d])){p=b[d];break}},addHandler:function(a,b,d){a.addEventListener?a.addEventListener(b,d,!1):a.attachEvent?a.attachEvent("on"+b,d):a["on"+b]=d},clickHeat:function(a){a||(a=f[a]);var b=a.target||a.srcElement;"IMG"===b.tagName&&(b=b.parentNode);var b="A"===b.tagName?1:0,d=a.which||a.button,k=a.clientX;a=a.clientY;var g=f.pageYOffset||l.scrollTop,k=k+(f.pageXOffset||l.scrollLeft);a+=g;var g=l.clientWidth||f.innerWidth,r=f.location.href,c=[];c.push("id=4781177");
c.push("x="+k);c.push("y="+a);c.push("w="+g);c.push("s="+f.screen.width+"x"+f.screen.height);c.push("b="+p);c.push("c="+d);c.push("r="+m(e.referrer));c.push("a="+b);""!==f.location.hash&&c.push("p="+m(r));c.push("random="+m(Date()));var b=c.join("&"),h=new Image;h.onload=h.onerror=h.onabort=function(){h=h.onload=h.onerror=h.onabort=null};h.src="http://hm2.cnzz.com/heatmap.gif?"+b;return!0},isValidUrl:function(){var a=f.location.href,b=!1,d="([{\\^$|)?+.]}".split("");f.location.pathname||
(a+="/");for(var k=0;k<n.length;k++){var g=n[k];if(-1!==g.indexOf("*")){for(var e=0;e<d.length;e++)var c="/\\"+d[e]+"/g",g=g.replace(eval(c),"\\"+d[e]);c="/\\*/g";g=g.replace(eval(c),"(.*)");c=RegExp(g,"i");if(c.test(a)){b=!0;break}}else if(g===a){b=!0;break}}return b}};new q}catch(s){}})();

